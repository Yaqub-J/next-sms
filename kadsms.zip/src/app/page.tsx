
const Homepage = () => {
  return (
    <div className="ng"><h1>admin <link href="/admin" /></h1></div>
  )
}

export default Homepage